<?php
	header("Content-type: text/javascript");
	if($_GET['lo']=='login-signup'){
?>
$(document).ready(function(e) {
	$("#go").click(function(v){
		v.preventDefault();
		var stt = $("#status-login");
		stt.fadeOut();
		if($(".form-username").val() == ''){
			stt.fadeIn();
			stt.addClass("bg-danger");
			stt.html("Vui lòng nhập tài khoản và mật khẩu");
			$("#form-username").addClass("danger-form");
		}else{
			$("#form-username").removeClass("danger-form");
		}
		if($(".form-password").val() == ''){
			stt.html("Vui lòng nhập tài khoản và mật khẩu");
			stt.fadeIn();
			stt.addClass("bg-danger");
			$("#form-password").addClass("danger-form");
		}else{
			$("#form-password").removeClass("danger-form");
		}
		if($(".form-password").val() != '' && $(".form-username").val() != ''){
		$.ajax({
    	    url : "cot-ajax.php",
        	type : "post",
     	   dataType:"json",
     	   data : {
     	   		type : "login",
     	   		user : $(".form-username").val(),
     	   		pass : $(".form-password").val(),
     	   },
     	   success : function (result){
     	       if(result.err == 1){
     	       		stt.fadeIn();
					stt.addClass("bg-danger");
					stt.html(result.text);
					window.location.reload();
     	       }else if(result.err == 2){
     	       		stt.fadeIn();
					stt.addClass("bg-danger");
					stt.html(result.text);
     	       }
     	   }
        	    });
		}
	});
});
<?php
	}
?>