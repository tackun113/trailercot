<?php

function is_string_cot($var){

	if(preg_match("/<-.*->/", '', $var)){

		return true;

	}else{

		return false;

	}

}

function is_array_cot($var){

	foreach ($var as $key => $value) {

		if(array_key_exists('id',$value)){

			$result = true;

		}else{

			$result = false;

			break;

		}

	}

	if($result){

		return true;

	}else{

		return false;

	}



}

class DataCot{

	private $var;

	private $method;

	public $string;

	public $array;

	public function __construct($var){

		$this->var = $var;

		if(is_array($var)){

			$this->method = 1;

			$this->array = $this->var;

			$this->string = $this->to_string($var);

		}else{

			$this->method = 2;

			$this->string = $this->var;

			$this->array = $this->to_array($var);

		}



	}

	public function to(){

		if($this->method == 1){

			return $this->to_string($this->var);

		}else{

			return $this->to_array($this->var);

		}

	}

	private function to_array($string){

		$data = preg_replace("/<-.*->/", '', $string);

		$data = trim($data, "\n");

		$title = str_replace($data, '', $string);

		$title = trim($title, "\n");

		$title =str_replace('<-', '', $title);

		$title =str_replace("->", '', $title);

		$title = explode(":", $title);

		$data = explode("\n", $data);

		foreach ($data as $key => $value) {

			$data[$key] = explode(":", $value);

		}

		$data_new = array();

		foreach ($data as $key => $value) {

			foreach ($value as $key1 => $value1) {

				$data_new[$value[0]][$title[$key1]] = $value1;

			}

		}

		return $data_new;		

	}

	private function to_string($array){

		$title = array();

		$data = '';

		foreach ($array as $key => $value) {

			foreach ($value as $key => $value) {

				if(!in_array($key, $title)){

					$title[]=$key;

				}

				$data .= $value.':';

			}

			$data = rtrim($data,':');

			$data = $data."\n";

		}

		$title_new = '';

		foreach ($title as $key => $value) {

			$title_new .= $value.':';

		}

		$title_new = '<-'.rtrim($title_new,':').'->';

		return($title_new."\n".$data);

	}

}

?>