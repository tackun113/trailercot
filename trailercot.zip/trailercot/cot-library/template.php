<?php

function get_dir_theme_active(){

	return get_option('theme');

}

function get_theme($dir){

	global $ManagerTheme;

	return $ManagerTheme->get_info_page($dir);

}

function get_theme_active($dir){

	return set_option('theme',$dir);

}

class Template{

	public $template = array(

			'index' => 'index.php',

			'insert-form' => 'addcontent.php',

			'search' => 'search.php',

			'404' => '404.php',

			'header' => 'header.php',

			'footer' => 'footer.php'

		);

	public $template_hidden = array(

			'header',

			'footer'

		);

	public $dir_theme;

	public $url_theme;

	function __construct(){

		$this->dir_theme = get_dir_theme_active();

		$this->url_theme = array(

				'1' => HOME.'/cot-content/themes'.'/'.$this->dir_theme,

				'2' => get_option('url').'/cot-content/themes'.'/'.$this->dir_theme

			);

	}

	public function set_template($name,$file_name){

		$this->template[$name] = $file_name;

	}

	public function set_template_hidden($name){

		$this->template_hidden[$name] = true;

	}

	public function delete_template($name){

		unset($this->template[$name]);

	}

	public function get_template($name){

		$url = $this->url_theme[1].'/'.$this->template[$name];

		if(file_exists($url)){

			require_once($url);

			return true;

		}else{

			return false;

		}

	}

}

$Template = new Template;

function is_($name){

	global $Template;

	if(array_key_exists($name, $Template->template)){

		if($_SERVER['PHP_SELF']=='/'.$Template->template[$name] && !array_key_exists($name, $Template->template_hidden)){

			return true;

		}else{

			return false;

		}		

	}else{

		return false;

	}

}

function is_index(){

	return is_('index');

}

function is_search(){

	return is_('search');

}

function is_404(){

	return is_('404');

}

function id_addcontent(){

	return is_('addcontent');

}

function get_title($func=''){

	if($func == ''){

		if(is_index()){

			$result = __('Home Page').' | '.get_option('title');

		}elseif(is_search()){

			$result = __('Search Page').' | '.get_option('title');

		}elseif(is_404()){

			$result = __('404 Page').' | '.get_option('title');

		}elseif(is_addcontent()){

			$result = __('AddContent Page').' | '.get_option('title');

		}

		return '<title>'.$result.'</title>';

	}else{

		return $func();

	}

}

function title(){

	echo get_title();

}
add_action('title','title');
