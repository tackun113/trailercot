<?php
	header("Content-type: text/css");
	if($_GET['lo']=='admin'){
?>
body{
	background-color: #2a3f54;
}
.mainer{
	padding: 20px;
	text-align: center;
	margin: 100px;
	border-radius: 3px;
}
.x_panel{
	width: 100%;
	padding: 10px 17px;
	display: inline-block;
	background: #fff;
	border: 1px solid #E6E9ED;
-webkit-column-break-inside: avoid;
-moz-column-break-inside: avoid;
	column-break-inside: avoid;
	opacity: 1;
	transition: all .2s ease;
	margin-bottom: 10px;
}
.x_title ul{
	min-width: 70px;
}
.x_title{
	border-bottom: 2px solid #E6E9ED;
	padding: 1px 5px 6px;
	margin-bottom: 10px;
}
.x_title h2{
	margin: 5px 0 6px;
	float: left;
	display: block;
	font-size: 18px;
	font-weight: 400;
	overflow: hidden;
	text-overflow: ellipsis;
}
.x_title li{
	float: right;
	cursor: pointer;
}
.x_title li a{
	padding: 5px;
	color: #C5C7CB;
	font-size: 14px;
	display: block;
}
.x_title li a:hover{
	background:#eee!important;
}
.x_title li a i{
	width: auto !important;
	font-size: inherit !important;
}
.x_content{
	padding: 0 5px 6px;
	float: left;
	clear: both;
	margin-top: 5px;
	width: 100%;
}
.x_content p{
	font-size: 13px;
	font-weight: 400;
	line-height: 1.471;
}
.count_top{
	font-size: 13px;
}
.count_bottom{
	font-size: 13px;
}
.count_bottom i{
	width: 12px;
}
.green{
	color: #1ABB9C;
}
.count{
	font-size: 40px;
	line-height: 47px;
	font-weight: 600;
}
.title_info{
	width: 100%;
}
.title_info p{
	margin:0px;
}
.title-count{
	margin-bottom: 20px;
	margin-top: 20px;
}
.title-count .tile-stats-count::before{
	content: "";
	position: absolute;
	left: 0;
	height: 65px;
	border-left: 2px solid #ADB2B5;
	margin-top: 10px;
}
.row{
	margin-right: -10px;
	margin-left: -10px;
}
.tile-stats-count{
	color: #52779c;
	margin-bottom: 10px;
	border-bottom: 0;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
	padding: 0 10px 0 20px;
	padding-bottom: 20px;
	position: relative;
}
.main-menu{
	padding:0px;
}
.main-admin{
	background: #F7F7F7;
	min-height: 100vh;
}
.menu-down{
	position: absolute;
	background: #fff;
	border: 1px solid #D9DEE4;
-webkit-box-shadow: none;
	right: 0;
	left: auto;
	width: 220px;
	top: 100%;
	padding:0px;
	display:none;
	z-index:10;
}
.menu-down li{
	list-style-type:none;
}
.menu-down a{
	float:none !important;
	display: block;
	padding: 5px 20px !important;
	font-weight: 400;
	line-height: 1.42857143;
	color: #5b6f8f;
	white-space: nowrap;
	scroll-behavior: ;
	font-size: 13px;
}
.fill-nav-right a:hover{
	text-decoration: none;
	background: #dedbdb;
	cursor: pointer;
}
.fill-nav-right{
	position: relative;
}
.fill-nav-right a{
	float:right;
	color: #515356;
	font-weight: 500;
	line-height: 32px;
	padding:12px;
	padding-right:20px;
}
.fill-nav-right img{
	width: 29px;
	height: 29px;
	border-radius: 50%;
	margin-right: 10px;
}
.fill-top{
	float: left;
	background: #EDEDED;
	border-bottom: 1px solid #D9DEE4;
	width: 100%;
}
.right-col{
	padding: 10px 20px 0;
	margin-left: 230px;
}
.menu-section{
	margin-top: 10px;
	margin-bottom: 10px;
}
.nav a{
	color: #E7E7E7;
	font-weight: 500;
}
.nav a:hover{
	background: #1e2e3f !important;
	cursor:pointer;
}
.nav .active{
	background: #1e2e3f !important;
}
.nav .fa{
	width: 26px;
	opacity: .99;
	display: inline-block;
	font-family: FontAwesome;
	font-style: normal;
	font-weight: 400;
	font-size: 18px;
}
.menu-section h3{
	padding-left: 15px;
	color: #fff;
	text-transform: uppercase;
	letter-spacing: .5px;
	font-weight: 700;
	font-size: 11px;
	margin-bottom: 0;
	margin-top: 0;
	text-shadow: 1px 1px #000;
}
.main{
	width:100%;
	padding:0px;
}
.menu{
	background: #2A3F54;
	min-height: 100vh;
	padding: 0;
	display: -ms-flexbox;
	display: flex;
	z-index: 1;
}
.img-circle.profile_img {
    width: 70%;
    background: #fff;
    margin-left: 15%;
    z-index: 1000;
    position: inherit;
    margin-top: 20px;
    border: 1px solid rgba(52,73,94,.44);
    padding: 4px;
}
.profile span{
	font-size: 13px;
	line-height: 30px;
	color: #BAB8B8;
}
.profile h2{
	font-size: 14px;
	color: #ECF0F1;
	margin: 0;
	font-weight: 300;
}
.pic{
	float:left;
	width:35%;
}
.name{
	padding: 25px 10px 10px;
	width: 65%;
	float:left;
}
.clear{
	clear:both;
}
<?php
	}
	if($_GET['lo']=='login-signup'){
?>
.danger-form{
	border: 1px solid #a55454 !important;
}
input[type="text"], 
input[type="password"], 
textarea, 
textarea.form-control {
	height: 50px;
    margin: 0;
    padding: 0 20px;
    vertical-align: middle;
    background: #fff;
    border: 3px solid #fff;
    font-family: 'Roboto', sans-serif;
    font-size: 16px;
    font-weight: 300;
    line-height: 50px;
    color: #888;
    -moz-border-radius: 4px; -webkit-border-radius: 4px; border-radius: 4px;
    -moz-box-shadow: none; -webkit-box-shadow: none; box-shadow: none;
    -o-transition: all .3s; -moz-transition: all .3s; -webkit-transition: all .3s; -ms-transition: all .3s; transition: all .3s;
}

textarea, 
textarea.form-control {
	padding-top: 10px;
	padding-bottom: 10px;
	line-height: 30px;
}

input[type="text"]:focus, 
input[type="password"]:focus, 
textarea:focus, 
textarea.form-control:focus {
	outline: 0;
	background: #fff;
    border: 3px solid #fff;
    -moz-box-shadow: none; -webkit-box-shadow: none; box-shadow: none;
}

input[type="text"]:-moz-placeholder, input[type="password"]:-moz-placeholder, 
textarea:-moz-placeholder, textarea.form-control:-moz-placeholder { color: #888; }

input[type="text"]:-ms-input-placeholder, input[type="password"]:-ms-input-placeholder, 
textarea:-ms-input-placeholder, textarea.form-control:-ms-input-placeholder { color: #888; }

input[type="text"]::-webkit-input-placeholder, input[type="password"]::-webkit-input-placeholder, 
textarea::-webkit-input-placeholder, textarea.form-control::-webkit-input-placeholder { color: #888; }



button.btn {
	height: 50px;
    margin: 0;
    padding: 0 20px;
    vertical-align: middle;
    background: #19b9e7;
    border: 0;
    font-family: 'Roboto', sans-serif;
    font-size: 16px;
    font-weight: 300;
    line-height: 50px;
    color: #fff;
    -moz-border-radius: 4px; -webkit-border-radius: 4px; border-radius: 4px;
    text-shadow: none;
    -moz-box-shadow: none; -webkit-box-shadow: none; box-shadow: none;
    -o-transition: all .3s; -moz-transition: all .3s; -webkit-transition: all .3s; -ms-transition: all .3s; transition: all .3s;
}

button.btn:hover { opacity: 0.6; color: #fff; }

button.btn:active { outline: 0; opacity: 0.6; color: #fff; -moz-box-shadow: none; -webkit-box-shadow: none; box-shadow: none; }

button.btn:focus { outline: 0; opacity: 0.6; background: #19b9e7; color: #fff; }

button.btn:active:focus, button.btn.active:focus { outline: 0; opacity: 0.6; background: #19b9e7; color: #fff; }

body {
    font-family: 'Roboto', sans-serif;
    font-size: 16px;
    font-weight: 300;
    color: #888;
    line-height: 30px;
    text-align: center;
}

strong { font-weight: 500; }

a, a:hover, a:focus {
	color: #19b9e7;
	text-decoration: none;
    -o-transition: all .3s; -moz-transition: all .3s; -webkit-transition: all .3s; -ms-transition: all .3s; transition: all .3s;
}

h1, h2 {
	margin-top: 10px;
	font-size: 38px;
    font-weight: 100;
    color: #555;
    line-height: 50px;
}

h3 {
	font-size: 22px;
    font-weight: 300;
    color: #555;
    line-height: 30px;
}

img { max-width: 100%; }

::-moz-selection { background: #19b9e7; color: #fff; text-shadow: none; }
::selection { background: #19b9e7; color: #fff; text-shadow: none; }


.btn-link-1 {
	display: inline-block;
	height: 50px;
	margin: 5px;
	padding: 16px 20px 0 20px;
	background: #19b9e7;
	font-size: 16px;
    font-weight: 300;
    line-height: 16px;
    color: #fff;
    -moz-border-radius: 4px; -webkit-border-radius: 4px; border-radius: 4px;
}
.btn-link-1:hover, .btn-link-1:focus, .btn-link-1:active { outline: 0; opacity: 0.6; color: #fff; }

.btn-link-1.btn-link-1-facebook { background: #4862a3; }
.btn-link-1.btn-link-1-twitter { background: #55acee; }
.btn-link-1.btn-link-1-google-plus { background: #dd4b39; }

.btn-link-1 i {
	padding-right: 5px;
	vertical-align: middle;
	font-size: 20px;
	line-height: 20px;
}

.btn-link-2 {
	display: inline-block;
	height: 50px;
	margin: 5px;
	padding: 15px 20px 0 20px;
	background: rgba(0, 0, 0, 0.3);
	border: 1px solid #fff;
	font-size: 16px;
    font-weight: 300;
    line-height: 16px;
    color: #fff;
    -moz-border-radius: 4px; -webkit-border-radius: 4px; border-radius: 4px;
}
.btn-link-2:hover, .btn-link-2:focus, 
.btn-link-2:active, .btn-link-2:active:focus { outline: 0; opacity: 0.6; background: rgba(0, 0, 0, 0.3); color: #fff; }

.btn-link-2 i {
	padding-right: 5px;
	vertical-align: middle;
	font-size: 20px;
	line-height: 20px;
}


/***** Top content *****/

.inner-bg {
    padding: 60px 0 80px 0;
}

.top-content .text {
	color: #fff;
}

.top-content .text h1 { color: #fff; }

.top-content .description {
	margin: 20px 0 10px 0;
}

.top-content .description p { opacity: 0.8; }

.top-content .description a {
	color: #fff;
}
.top-content .description a:hover, 
.top-content .description a:focus { border-bottom: 1px dotted #fff; }

.clear{
	clear:both;
}

.stt{
	padding: 10px;
	border-radius: 3px;
	overflow: hidden;
	display:none;
}

.form-box {
	margin-top: 70px;
	margin-right: 100px;
}

.form-top {
	overflow: hidden;
	padding: 0 25px 15px 25px;
	background: #444;
	background: rgba(0, 0, 0, 0.35);
	-moz-border-radius: 4px 4px 0 0; -webkit-border-radius: 4px 4px 0 0; border-radius: 4px 4px 0 0;
	text-align: left;
}

.form-top-left {
	float: left;
	width: 75%;
	padding-top: 25px;
}

.form-top-left h3 { margin-top: 0; color: #fff; }
.form-top-left p { opacity: 0.8; color: #fff; }

.form-top-right {
	float: left;
	width: 25%;
	padding-top: 5px;
	font-size: 66px;
	color: #fff;
	line-height: 100px;
	text-align: right;
	opacity: 0.3;
}

.form-bottom {
	padding: 25px 25px 30px 25px;
	background: #444;
	background: rgba(0, 0, 0, 0.3);
	-moz-border-radius: 0 0 4px 4px; -webkit-border-radius: 0 0 4px 4px; border-radius: 0 0 4px 4px;
	text-align: left;
}

.form-bottom form textarea {
	height: 100px;
}

.form-bottom form button.btn {
	width: 100%;
}

.form-bottom form .input-error {
	border-color: #19b9e7;
}

.social-login {
	margin-top: 35px;
}

.social-login h3 {
	color: #fff;
}

.social-login-buttons {
	margin-top: 25px;
}

.middle-border {
	min-height: 300px;
	margin-top: 170px;
	border-right: 1px solid #fff;
	border-right: 1px solid rgba(255, 255, 255, 0.6);
}


/***** Footer *****/

footer {
	padding-bottom: 70px;
	color: #fff;
}

footer .footer-border {
	width: 200px;
	margin: 0 auto;
	padding-bottom: 30px;
	border-top: 1px solid #fff;
	border-top: 1px solid rgba(255, 255, 255, 0.6);
}

footer p { opacity: 0.8; }

footer a {
	color: #fff;
}
footer a:hover, footer a:focus { color: #fff; border-bottom: 1px dotted #fff; }


/***** Media queries *****/

@media (min-width: 992px) and (max-width: 1199px) {}

@media (min-width: 768px) and (max-width: 991px) {}

@media (max-width: 767px) {
	
	.middle-border { min-height: auto; margin: 65px 30px 0 30px; border-right: 0; 
						border-top: 1px solid #fff; border-top: 1px solid rgba(255, 255, 255, 0.6); }
	
}

@media (max-width: 415px) {
	
	h1, h2 { font-size: 32px; }

}


<?php
	}

?>