<pre><?php

class Hook{

	public $args = array();

	public function add($action, $func, $stt=''){

		if($stt==''){
			if(array_key_exists($action, $this->args)){

				$i = 0;

				$max = '';

				foreach ($this->args[$action] as $key => $value) {
					
					if($i==0){

						$max = $key;

					}else{

						if($max < $key ){

							$max = $key;

						}
					}

					$i++;

				}

				$this->args[$action][$max+1] = $func;

			}else{
				
				$this->args[$action] = array($func);
			
			}
		
		}else{

			$this->args[$action][$stt] = $func;

		}

		ksort($this->args[$action]);

	}

	public function do($action){

		foreach ($this->args[$action] as $key => $value) {
			
			$value();

		}

	}

	public function del($action, $func=''){

		if($func==''){

			unset($this->args[$action]);

		}else{

			unset($this->args[$action][array_search($func, $this->args[$action])]);

		}

	}

}

$Hook = new Hook;

function add_action($action, $func, $stt=''){

	global $Hook;

	$Hook->add($action, $func, $stt);

}

function do_action($action){

	global $Hook;

	$Hook->do($action);

}

function delete_action($action, $func=''){

	global $Hook;

	$Hook->del($action, $func);

}

?>