<?php

class User{

	public $array_all = array();

	public $id;

	public $name;

	public $birthday;

	public $ip;

	public $language;

	public $level;

	public $username;

	public $passwordmd5;

	public $email;

	public function __construct($var){

		if(get_user_by_id($var)){

			$this->array_all = get_user_by_id($var);

		}else{

			$this->array_all = get_user_by_username($var);

		}

		$this->id = $this->array_all['id'];

		$this->name = $this->array_all['name'];

		$this->birthday = $this->array_all['birthday'];

		$this->ip = $this->array_all['ip'];

		$this->language = $this->array_all['language'];

		$this->level = $this->array_all['level'];

		$this->username = $this->array_all['username'];

		$this->passwordmd5 = $this->array_all['password'];

		$this->email = $this->array_all['email'];

	}

	public function get_contents(){

		return get_content_by_userid($this->id);

	}

	public function count_contents(){

		return count(get_content_by_userid($this->id));

	}

}

?>