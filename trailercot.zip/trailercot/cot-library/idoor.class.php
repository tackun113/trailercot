<?php

class ManagerIdoor{

	public $dirpath;

	public $qdir;

	public $countdir;

	public $infopage;

	public function __construct($path){

		$this->dirpath = HOME.'/cot-content/'.$path;

		$this->count_page();

		$this->page();

	}

	public function count_page(){

		$countall = array_diff(scandir($this->dirpath, 1), array('..', '.'));

		foreach($countall as $key=>$value){

			if(!is_dir($this->dirpath.'/'.$value) || !file_exists($this->dirpath.'/'.$value.'/main.css')){

				unset($countall[$key]);

			}

		}

		$this->qdir = $countall;

		$this->countdir = count($countall);

		return $this->countdir;

	}

	public function page(){

		$page = array();

		$i=0;

		foreach($this->qdir as $key=>$value){

			$fp = @fopen($this->dirpath.'/'.$value.'/main.css', "r");

			if (!$fp) {

				return '';

			}

			else{

				$data = fread($fp, filesize($this->dirpath.'/'.$value.'/main.css'));

				$cut = strstr($data,'*/');

				$data = str_replace($cut, '', $data );

				$data = str_replace('/*', '', $data);

				if(file_exists($this->dirpath.'/'.$value.'/screenshots.png')){

					$data = $data."\nscreenshots:".$this->dirpath.'/'.$value.'/screenshots.png';

				}elseif(file_exists($this->dirpath.'/'.$value.'/screenshots.jpg')){

					$data = $data."\nscreenshots:".$this->dirpath.'/'.$value.'/screenshots.jpg';					

				}elseif(file_exists($this->dirpath.'/'.$value.'/screenshots.jpeg')){

					$data = $data."\nscreenshots:".$this->dirpath.'/'.$value.'/screenshots.jpeg';	

				}else{

					$data = $data."\nscreenshots:images/no-image.png";	

				}

				$data = $data."\ndir:".$value;

				$data = explode("\n",$data);

				foreach($data as $key=>$value){

					$data[$key] = explode(':',$data[$key]);

				}

			}

			$data_post[$i]=$data;

			$i++;

		}

		$data_new=array();

		foreach($data_post as $key=>$value){

			foreach($value as $ke=>$valu){

				if(isset($valu[1])){

					$val_new = '';

					for($i=1;$i<count($valu);$i++){

						$val_new .= $valu[$i];

					}

					$data_new[$key][$valu[0]] = trim($val_new);

				}

			}

		}

		$this->infopage = $data_new;

		return $data_new;

	}

	public function get_info_page_where($name,$valuepage){

		$i=0;

		$result =array();;

		foreach($this->infopage as $key=>$value){

			if($value[$name]==$valuepage){

				 $result[$i]=$value;

				 $i++;

			}

		}

		return $result;

	}

	public function get_info_page($dir){

		foreach($this->infopage as $key=>$value){

			if($value['dir']==$dir){

				return $value;

				break;

			}

		}

	}

}

$ManagerTheme = new ManagerIdoor('themes');