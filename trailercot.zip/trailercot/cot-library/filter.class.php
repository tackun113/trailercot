<?php

class Filter(){
	
	public $args = array();

	public function apply($filter,$func){
		
		$this->args[$filter] = $func;

	}

	public function do($filter,$default=''){

		if(array_key_exists($filter, $this->args){

			$this->args[$filter]();

		}else{

			$default();

		}

	}

}

$Filter = new Filter;

function apply_filter($filter,$func){

	global $Filter;

	$Filter->apply($filter,$func);

}

function do_filter($filter,$default=''){

	global $Filter;

	$Filter->do($filter,$default);

}
