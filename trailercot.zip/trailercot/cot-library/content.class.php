<?php  

class Content{

	public $array_all = array();

	public $id;

	public $content;

	public $date;

	public $parent;

	public $emotion;

	public $popular;

	public $language;

	public $confirm;

	public $type_code;

	public $type_phr_code;

	public $type;

	public $type_phr;

	public $type_code_args = array();

	public $type_phr_code_args = array();

	public function __construct($var){

		$this->type_code_args = array(__('Từ, Cụm Từ'),__('Câu'));

		$this->type_phr_code_args = array(__('Hỏi'),__('Trả lời'),__('Cảm'),__('Chào'),__('Đối thoại ngang hàng'));

		if(get_content_by_id($var)){

			$this->array_all = get_content_by_id($var);

		}else{

			$this->array_all = get_content_by_content($var);

		}

		$this->id = $this->array_all['id'];

		$this->content = $this->array_all['content'];

		$this->date = $this->array_all['date'];

		$this->parent = $this->array_all['id_parent'];

		$this->emotion = $this->array_all['emotion'];

		$this->popular = $this->array_all['popular'];

		$this->language = $this->array_all['language'];

		$this->confirm = $this->array_all['confirm'];

		$this->type_code = $this->array_all['type'];

		$this->type_phr_code = $this->array_all['type_phr'];

		$this->type = $this->type_code_args[$this->type_code];

		$this->type_phr = $this->type_phr_code_args[$this->type_phr_code];

	}

}
?>