<?php
require_once("mopo/gettext.php");
require_once("mopo/streams.php");
$locale_file = new FileReader($_SERVER['DOCUMENT_ROOT']."/cot-content/languages/en_US.mo");
$loacle_fetch = new gettext_reader($locale_file);
function __($text){
	global $loacle_fetch;
	return $loacle_fetch->translate($text);
}
function _e($text){
	global $loacle_fetch;
	return $loacle_fetch->translate($text);
}
?>