<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "short_link";
$conn = mysqli_connect($servername, $username, $password, $dbname);
mysqli_set_charset($conn,'utf8');
function get_url_avatar($email,$size){
	$email = trim($email);
	$email = strtolower($email);
	$email_hash = md5($email);
	return 'http://www.gravatar.com/avatar/'.$email_hash.'?s='.$size;
}
function rand_chars(){
	$string = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ012345678';
	$size = strlen($string);
	$str = '';
	for($i=0;$i<7;$i++){
		$str .= $string[ rand( 0, $size - 1 ) ];
	}
	return $str;
}
function get_site($key_site){
	global $conn;
	$key_site = addslashes($key_site);
	$sql="SELECT value_site FROM site WHERE key_site='".$key_site."'";
	$result = mysqli_query($conn, $sql);
	if(mysqli_num_rows($result)==0){
		return false;
	}else{
		return mysqli_fetch_assoc($result)['value_site'];
	}
}
function get_user_id($id){
	global $conn;
	$sql="SELECT * FROM user WHERE id='".(int)$id."'";
	$result = mysqli_query($conn, $sql);
	if(mysqli_num_rows($result)==0){
		return false;
	}else{
		return mysqli_fetch_assoc($result);
	}
}
function get_user_right($right){
	global $conn;
	$sql="SELECT * FROM user WHERE right_admin='".(int)$right."'";
	$result = mysqli_query($conn, $sql);
	if(mysqli_num_rows($result)==0){
		return false;
	}else{
		return mysqli_fetch_assoc($result);
	}
}
function get_user_username($username){
	global $conn;
	$username = addslashes($username);
	$sql="SELECT * FROM user WHERE username='".$username."'";
	$result = mysqli_query($conn, $sql);
	if(mysqli_num_rows($result)==0){
		return false;
	}else{
		return mysqli_fetch_assoc($result);
	}
}
function add_link($link){
	global $conn;
	$link = addslashes($link);
	while(1==1){
		$code = rand_chars();
		$sql_check="SELECT * FROM link WHERE code='".$code."'";
		$result_check = mysqli_query($conn, $sql_check);
		if(mysqli_num_rows($result_check)==0){
			break;
		}
	}
	$sql ="INSERT INTO link (code,link) VALUES ('".$code."','".$link."')";
	$result = mysqli_query($conn, $sql);
	if($result){
		return true;
	}else{
		return false;
	}
}
function isset_link_in($link){
	global $conn;
	$link = addslashes($link);
	$sql = "SELECT * FROM link WHERE link='".$link."'";
	$result = mysqli_query($conn, $sql);
	if (mysqli_num_rows($result)>0){
		return true;
	}else{
		return false;
	}
}
function isset_code_in($code){
	global $conn;
	$code = addslashes($code);
	$sql = "SELECT * FROM link WHERE code='".$code."'";
	$result = mysqli_query($conn, $sql);
	if (mysqli_num_rows($result)>0){
		return true;
	}else{
		return false;
	}
}
function get_link($link){
	global $conn;
	$link = addslashes($link);
	$sql = "SELECT * FROM link WHERE link='".$link."'";
	$result = mysqli_query($conn, $sql);
	if(isset_link_in($link)){
		return mysqli_fetch_assoc($result);
	}else{
		return false;
	}
}
function get_all_link(){
	global $conn;
	$sql = "SELECT * FROM link";
	$result = mysqli_query($conn, $sql);
	if($result){
		return mysqli_fetch_assoc($result);
	}else{
		return false;
	}
}
function get_code($code){
	global $conn;
	$code = addslashes($code);
	$sql = "SELECT * FROM link WHERE code='".$code."'";
	$result = mysqli_query($conn, $sql);
	if(isset_code_in($code)){
		return mysqli_fetch_assoc($result);
	}else{
		return false;
	}
}
?>
