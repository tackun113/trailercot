<?php

$Conn = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

function query($sql){

	global $Conn;

	return $Conn->query($sql);

}

function get_option($key){

	$key = addslashes($key);

	$sql = "SELECT value_option FROM cot_options WHERE key_option='".$key."'";

	$result = query($sql);

	if ($result->num_rows > 0) {

    	return $result->fetch_assoc()['value_option'];

	} else {

	    return false;

	}

}

function set_option($key,$value){

	$key = addslashes($key);

	$value = addslashes($value);

	if(get_option($key)){

		$sql = "UPDATE cot_options SET value_option='".$value."' WHERE key_option='".$key."'";

	}else{

		$sql = "INSERT INTO cot_options (key_option, value_option) VALUES ('".$key."','".$value."')";

	}

	if(query($sql) == true){

		return true;

	}else{

		return false;

	}	

}

function destroy_option($key){

	$key = addslashes($key);

	$sql = "DELETE FROM cot_options WHERE key_option='".$key."'";

	if(query($sql)){

		return true;

	}else{

		return false;

	}

}

function option(){

	$sql = "SELECT * FROM cot_options";

	$result = query($sql);

	$bsd =array();

	if ($result->num_rows > 0) {

    	while($row = $result->fetch_assoc()){

    		$bsd[$row['id']]=$row;

    	}

    return $bsd;

	} else {

	    return false;

	}

}

function content(){

	$sql = "SELECT * FROM cot_contents";

	$result = query($sql);

	if ($result->num_rows > 0) {

    	while($row = $result->fetch_assoc()){

    		$bsd[$row['id']]=$row;

    	}

    return $bsd;

	} else {

	    return false;

	}		

}

function get_content($key,$value){

	if(is_array($key) && is_array($value)){

		$string ='';

		foreach ($key as $key1 => $value1) {

			$string .= $value1."='".$value[$key1]."' AND ";

		}

		$string = rtrim($string,'AND ');

		$sql = "SELECT * FROM cot_contents WHERE ".$string;

		$result = query($sql);

		if ($result->num_rows > 0) {

	    	while($row = $result->fetch_assoc()){

	    		$bsd[$row['id']]=$row;

	    	}

	    return $bsd;

		} else {

		    return false;

		}	

	}else{

		$key = addslashes($key);

		$value = addslashes($value);

		$sql = "SELECT * FROM cot_contents WHERE ".$key."='".$value."'";

		$result = query($sql);

		if ($result->num_rows > 0) {

	    	while($row = $result->fetch_assoc()){

	    		$bsd[$row['id']]=$row;

	    	}

	    return $bsd;

		} else {

		    return false;

		}			

	}

}

function get_content_by_id($ar){

	$ar = addslashes($ar);

	return get_content('id',$ar)[$ar];

}

function get_content_by_userid($ar){

	$ar = addslashes($ar);

	return get_content('id_user',$ar);

}

function get_content_by_content($ar){

	$ar = addslashes($ar);

	$result = get_content('content',$ar);

	foreach ($result as $key => $value) {

		$result = $value;

	}

	return $result;

}

function user(){

	$sql = "SELECT * FROM cot_users";

	$result = query($sql);

	if ($result->num_rows > 0) {

    	while($row = $result->fetch_assoc()){

    		$bsd[$row['id']]=$row;

    	}

    return $bsd;

	} else {

	    return false;

	}	

}

function get_user($key,$value){

	if(is_array($key) && is_array($value)){

		$string ='';

		foreach ($key as $key1 => $value1) {

			$string .= $value1."='".$value[$key1]."' AND ";

		}

		$string = rtrim($string,'AND ');

		$sql = "SELECT * FROM cot_users WHERE ".$string;

		$result = query($sql);

		$i = 0;

		if ($result->num_rows > 0) {

	    	while($row = $result->fetch_assoc()){

	    		$bsd[$i]=$row;

	    		$i++;

	    		echo $i;

	    	}

	    return $bsd;

		} else {

		    return false;

		}	

	}else{

		$key = addslashes($key);

		$value = addslashes($value);

		$sql = "SELECT * FROM cot_users WHERE ".$key."='".$value."'";

		$result = query($sql);

		$i = 0;

		if ($result->num_rows > 0) {

	    	while($row = $result->fetch_assoc()){

	    		$bsd[$i]=$row;

	    		$i++;

	    	}

	    return $bsd;

		} else {

		    return false;

		}			

	}

}

function set_user($username,$args){

	$result1 = '';
	
	$result2 = '';
	
	$result3 = '';
	
	foreach ($args as $key => $value) {

		$result1 .= $key."='".$value."',";

		$result2 .= $key.",";

		$result3 .= "'".$value."',";

	}

	$result1 = rtrim($result1,',');

	$result2 = rtrim($result2,',');
	
	$result3 = rtrim($result3,',');

	if(get_user_by_username($username)){

		$sql = "UPDATE cot_users SET ".$result1." WHERE username='".$username."'";

	}else{

		$sql = "INSERT INTO cot_users (".$result2.",username) VALUES (".$result3.",'".$username."')";

	}

	if(query($sql) == true){

		return true;

	}else{

		return false;

	}

}

function count_level_user($level){
	$lev = get_user('level',$level);
	if($lev){
		return count($lev);
	}else{
		return '0';
	}

}

function get_level($user){
	return get_user_by_username($user)['level'];
}

function get_user_by_id($ar){

	$ar = addslashes($ar);

	return get_user('id',$ar)[$ar];

}

function get_user_by_username($ar){

	$ar = addslashes($ar);

	$result = get_user('username',$ar);

	if($result){

		foreach ($result as $key => $value) {

			$result = $value;
		
		}

	}

	return $result;

}

function get_user_by_level($ar){

	$ar = addslashes($ar);

	return get_user('id',$ar);

}

?>