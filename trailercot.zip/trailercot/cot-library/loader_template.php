<?php

require_once(HOME.'/cot-content/themes/'.get_option('theme').'/function.php');

global $Template;

function get_template($name){

	global $Template;

	return $Template->get_template($name);

}

function get_index(){

	return get_template('index');

}


function get_search(){

	return get_template('search');

}

function get_404(){

	return get_template('404');

}

function get_addcontent(){

	return get_template('addcontent');

}

function get_header(){

	return get_template('header');

}

function get_footer(){

	return get_template('footer');

}

if(is_index()){

	get_index();

}elseif(is_search()){
	
	get_search();

}elseif(is_404()){

	get_404();

}elseif(is_addcontent()){

	get_addcontent();

}

?>