<?php
if(isset($_POST['type'])){
	require_once($_SERVER['DOCUMENT_ROOT'].'/cot-config.php');

	require_once(HOME.'/cot-library/database.function.php');
	$result = array();
	if($_POST['type']=='login'){
		$username = $_POST['user'];
		$pass = $_POST['pass'];
		$user = get_user_by_username($username);
		if(isset($user) && md5($pass) == $user['password'] ){
			$result['err'] = 1;
			$result['text'] = "Đăng nhập thành công, đang chuyển trang...";
			session_start();
			$_SESSION['user'] = $username;
		}else{
			$result['err'] = 2;
			$result['text'] = "Tài khoản hoặc mật khẩu không chính xác!";
		}
	echo json_encode($result,JSON_UNESCAPED_UNICODE);
	}
}
?>