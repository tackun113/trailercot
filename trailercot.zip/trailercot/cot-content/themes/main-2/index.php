<?php
global $ManagerPage;?>
<ul>
<?php foreach($ManagerPage->infopage as $key=>$value){?>
<li class="page-index">
	<div class="name"><a href="?id=<?php echo $value['dir']?>">
	<img class="thumbnai" src="<?php echo $value['screenshots']?>"/>
	<p><?php echo $value['Page Name']?></p></a></div>
	<div class="des"><p><?php echo $value['Description']?></p></div>
</li>
<?php
}
?>
</ul>
<pre><?php
print_r($ManagerPage);
?>