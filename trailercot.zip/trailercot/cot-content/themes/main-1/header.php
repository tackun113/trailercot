<head>
<?php do_action('title');?>
</head>