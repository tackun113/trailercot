<?php
$page = get_page();
get_header($page['Page Name']);
load_page();
?>
<body>
<button id="loginbutton" style="display:none">Đăng nhập</button>
<button id="actionbutton" style="display:none"></button>
<button id="logoutbutton" style="display:none">Đăng xuất</button>
<button id="sharebutton" style="display:none">Chia sẻ lên facebook</button>
<div id='save'></div>
</body>
