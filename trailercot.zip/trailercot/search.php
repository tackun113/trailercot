<?php

require_once($_SERVER['DOCUMENT_ROOT'].'/cot-load.php');

require_once(HOME.'/cot-library/loader_template.php');

?>