<?php
/** MySQL database name */
define('DB_NAME', 'trailercot');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** SERVER HOME  */
define('HOME',$_SERVER['DOCUMENT_ROOT']);

?>