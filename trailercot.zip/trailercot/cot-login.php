<?php
session_start();
require_once($_SERVER['DOCUMENT_ROOT'].'/cot-config.php');

require_once(HOME.'/cot-library/database.function.php');

require_once(HOME.'/cot-library/main.function.php');

if(is_login()){
	$level = get_level($_SESSION['user']);
	if($level == 1 || $level ==2){
		header('Location: '.get_option('url').'/cot-admin');
	}elseif($level ==3){
		header('Location: '.get_option('url').'/user');
	}

}else{
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="<?php echo get_option('url')?>/cot-library/css/main.css">
	<link rel="stylesheet" type="text/css" href="<?php echo get_option('url')?>/cot-library/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo get_option('url')?>/cot-library/bootstrap/css/bootstrap-theme.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo get_option('url')?>/cot-library/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo get_option('url')?>/cot-library/css-ct.php?lo=login-signup">
	<script type="text/javascript" src="<?php echo get_option('url')?>/cot-library/js/jquery-3.2.1.min.js"></script>
	<script type="text/javascript" src="<?php echo get_option('url')?>/cot-library/bootstrap/js/bootstrap.min.js"></script>
</head>
<div class="top-content">
<body>
<div class="inner-bg">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-7"></div>
 			<div class="col-md-5">
 				<div class="form-box">
	    		    <div class="form-top">
	    		    	<div class="form-top-left">
	                        <h3>Login to our site</h3>
	                        <p>Enter username and password to log on:</p>
	                    </div>
	                    <div class="form-top-right">
	                        <i class="fa fa-lock"></i>
	                    </div>
	                    <div class="clear"></div>
	                    <p class="stt" id="status-login">()</p>
	    		    </div>
	    		    <div class="form-bottom">
						<form role="form" action="" method="post" class="login-form">
						    <div class="form-group">
						    	<label class="sr-only" for="form-username">Username</label>
				   				<input type="text" name="form-username" placeholder="Username..." class="form-username form-control" id="form-username">
				  			</div>
				   			<div class="form-group">
				        		<label class="sr-only" for="form-password">Password</label>
				       			 <input type="password" name="form-password" placeholder="Password..." class="form-password form-control" id="form-password">
				    		</div>
				   			<button type="submit" class="btn" id="go">Sign in!</button>
				    	</form>
				    </div>
				</div>
 			</div>
	</div>
</div>
</div>
<script type="text/javascript" src="<?php echo get_option('url')?>/cot-library/js-ct.php?lo=login-signup"></script>

</body>
</html>
<?php

}

?>