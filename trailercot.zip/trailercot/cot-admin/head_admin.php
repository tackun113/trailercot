<?php
require_once($_SERVER['DOCUMENT_ROOT'].'/cot-config.php');

require_once(HOME.'/cot-library/database.function.php');

require_once(HOME.'/cot-library/main.function.php');

require_once(HOME.'/cot-library/user.class.php');

require_once(HOME.'/cot-library/render_languages.php');

require_once(HOME.'/cot-admin/miniapp_admin.php');

session_start();

if(isset($_GET['action'])){
	if($_GET['action']=='logout'){
		unset($_SESSION['user']);
	}
}

if(is_login()){

$user = new User(is_login());

$level[2] = array('home','profile','content');

$level[1] = array('home','profile','content','user','theme','title');

$menu = array(
		'home' => array(
			'url' => 'index.php',
			'title' => __('Home'),
			'icon' =>'home'
			),
		'profile' => array(
			'url' => 'index.php?menu=profile',
			'title' => __('Profile'),
			'icon' =>'user'
			),
		'content' => array(
			'url' => 'index.php?menu=content',
			'title' => __('Content'),
			'icon' =>'list'
			),
		'user' => array(
			'url' => 'index.php?menu=user',
			'title' => __('User'),
			'icon' =>'users'
			),
		'theme' => array(
			'url' => 'index.php?menu=theme',
			'title' => __('Theme'),
			'icon' =>'desktop'
			),
		'title' => array(
			'url' => 'index.php?menu=title',
			'title' => __('Title'),
			'icon' =>'square'
			),
	)
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="<?php echo get_option('url')?>/cot-library/css/main.css">
	<link rel="stylesheet" type="text/css" href="<?php echo get_option('url')?>/cot-library/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo get_option('url')?>/cot-library/bootstrap/css/bootstrap-theme.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo get_option('url')?>/cot-library/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo get_option('url')?>/cot-library/css-ct.php?lo=admin">
	<script type="text/javascript" src="<?php echo get_option('url')?>/cot-library/js/jquery-3.2.1.min.js"></script>
	<script type="text/javascript" src="<?php echo get_option('url')?>/cot-library/js-ct.php?lo=admin"></script>
	<script type="text/javascript" src="<?php echo get_option('url')?>/cot-library/bootstrap/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="<?php echo get_option('url')?>/cot-library/js/Chart.min.js"></script>
	<?php cot_head();?>
</head>
<body>
	<div class="container main" id="body_conteiner">
			<div class="col-md-2 menu">
				<div class="left-col">
					<div class="profile">
						<div class="pic"><img src="<?php echo get_option('url')?>/cot-library/image/pic-profile-ex.jpg" alt="..." class="img-circle profile_img"></div>
						<div class="name"><span><?php echo $user->username?></span><h2><?php echo $user->name?></h2></div>
					</div>
					<div class="clear"></div>
					<div class="side-bar">
						<div class="menu-section">
							<h3><?php echo __('GENERAL')?></h3>
						</div>
						<div class="menu-section">
							<ul class="nav menu-sidebar">
<?php
$active = '';
foreach ($level[$user->level] as $key => $value) {
if(isset($_GET['menu'])){
	$menu_a = $_GET['menu'];
}else{
	$menu_a = 'home';
}
	if($menu_a == $value){
		$active = 'active';
	}else{
		$active = '';
	}
?>
								<li><a class="<?php echo $value?> <?php echo $active;?>" href="<?php echo $menu[$value]['url']?>"><i class="fa fa-<?php echo $menu[$value]['icon']?>"></i> <?php echo $menu[$value]['title']?></a></li>
<?php
}
?>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-10 main-menu">
				<div class="fill-top">
					<div class="fill-nav-right">
						<a>
							<img src="<?php echo get_option('url')?>/cot-library/image/pic-profile-ex.jpg" alt="..."> 
							<?php echo $user->name?> <span class="fa fa-angle-down"></span>
						</a>
							<ul class="menu-down" id="down-soft">
								<li><a><?php echo __('Profile')?></a></li>
								<li><a href="?action=logout"><?php echo __('Log Out')?></a></li>
							</ul>
						<div class="clear"></div>
					</div>
				</div>
			</div>
			<?php main_admin()?>
	</div>
</body>
<script type="text/javascript">
	$(document).ready(function(e) {

		$('.fill-nav-right a').click(function(){
			if($('#down-soft').css('display') == 'none'){
				$('#down-soft').fadeIn();
			}else{
				$('#down-soft').fadeOut();
			}
		});
		$('.collapse-link').click(function(e){
			$(this).parents('.x_panel').children('.x_content').animate({
    			height: "toggle"
    			}, 200, 'swing', function() {
    			});
		});
	});
</script>
<?php
}else{
	header('Location:'.get_option('url').'/cot-login.php');
}
?>