<?php
function pie($data){
		$labels = '';
		$colors = '';
	foreach ($data as $key => $value) {
		$labels.='"'.$key.'",';
		$colors.='"'.$value.'",';
	}
	$labels = trim($labels,',');
	$colors = trim($colors,',');
?>
<table width='100%'>
                    <tbody><tr>
                      <th style="width:37%;">
                        <p class="green">Top 5</p>
                      </th>
                      <th>
                        <div class="col-lg-7 col-md-7 col-sm-7 col-xs-7 green">
                          <p class="">Device</p>
                        </div>
                        <div class="col-lg-5 col-md-5 col-sm-5 col-xs-5 green">
                          <p class="">Progress</p>
                        </div>
                      </th>
                    </tr>
                    <tr>
                      <td>
					<canvas id="contri" width="140" height="140"></canvas>
                      </td>
                      <td>
                        <table class="title_info">
                          <tbody><tr>
                            <td>
                              <p><i class="fa fa-square blue"></i>IOS </p>
                            </td>
                            <td>30%</td>
                          </tr>
                          <tr>
                            <td>
                              <p><i class="fa fa-square green"></i>Android </p>
                            </td>
                            <td>10%</td>
                          </tr>
                          <tr>
                            <td>
                              <p><i class="fa fa-square purple"></i>Blackberry </p>
                            </td>
                            <td>20%</td>
                          </tr>
                          <tr>
                            <td>
                              <p><i class="fa fa-square aero"></i>Symbian </p>
                            </td>
                            <td>15%</td>
                          </tr>
                          <tr>
                            <td>
                              <p><i class="fa fa-square red"></i>Others </p>
                            </td>
                            <td>30%</td>
                          </tr>
                        </tbody></table>
                      </td>
                    </tr>
                  </tbody>
</table>
<script>
$(document).ready(function(e) {
		var ctx = document.getElementById("contri").getContext('2d');
		var myChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
        datasets: [{
            label: '# of Votes',
            data: [<?php echo  count_level_user(1).','.count_level_user(2).','. count_level_user(3).','.count_level_user(4)?>],
            backgroundColor: [<?php echo $colors?>],
            borderWidth: 3
        }]
    }
});
});
</script>
<?php
}
?>
