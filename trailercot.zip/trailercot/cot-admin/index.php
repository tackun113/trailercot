<?php
require_once($_SERVER['DOCUMENT_ROOT'].'/cot-admin/head_admin.php');
function cot_head(){
?>

<?php
}
function main_admin(){
	global $user;
	global $level;
	if(isset($_GET['menu'])){
		if(in_array($_GET['menu'], $level[$user->level])){
?>
			<div class="col-md-10 main-admin">
				<div class="row title-count">
					<div class="col-md-2 col-sm-4 col-xs-6 tile-stats-count">
             			 <span class="count_top"><i class="fa fa-user"></i> <?php echo __('Total Users'); ?></span>
           			   <div class="count"><?php echo count(user());?></div>
           			   <span class="count_bottom"><i class="green">4% </i> <?php echo __('From last Week'); ?></span>
          		  </div>
				</div>
				<div class="row">
				<div class="col-md-4 col-sm-4 col-xs-12">
					<div class="x_panel title">
						<div class="x_title">
            		      <h2>App Versions</h2>
                		  	<ul class="nav navbar-right panel_toolbox">
                   				<li><a class="close-link"><i class="fa fa-close"></i></a></li>	 	
                   				<li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                		  	</ul>
                			<div class="clear"></div>
                		</div>
                		<div class="x_content">
                		</div>
					</div>
				</div>
				</div>
			</div>
<?php	}else{?>
<script>
	$(document).ready(function(e) {
		var bj = $('#body_conteiner');
		bj.empty();
		bj.html('<p class="bg-warning mainer"><?php echo __('Bạn không có quyền truy cập trang này')?></p>');
	});
</script>
<?php
}
}else{
?>
			<div class="col-md-10 main-admin">
				<div class="row title-count">
					<div class="col-md-2 col-sm-4 col-xs-6 tile-stats-count">
             			 <span class="count_top"><i class="fa fa-user"></i> <?php echo __('Total Users'); ?></span>
           			   <div class="count"><?php echo count(user());?></div>
           			   <span class="count_bottom"><i class="green">4% </i> <?php echo __('From last Week'); ?></span>
          		  </div>
				</div>
			</div>
<?php
	}
}
function cot_foot(){

}
require_once($_SERVER['DOCUMENT_ROOT'].'/cot-admin/foot_admin.php');
?>