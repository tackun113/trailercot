<?php
cot_foot();
?>