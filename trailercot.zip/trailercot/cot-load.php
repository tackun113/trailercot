<?php
require_once($_SERVER['DOCUMENT_ROOT'].'/cot-config.php');

require_once(HOME.'/cot-library/hook.class.php');

require_once(HOME.'/cot-library/filter.class.php');

require_once(HOME.'/cot-library/database.function.php');

require_once(HOME.'/cot-library/main.function.php');

require_once(HOME.'/cot-library/user.class.php');

require_once(HOME.'/cot-library/render_languages.php');

require_once(HOME.'/cot-library/template.php');


?>